<form wire:submit="submit" class="space-y-6" novalidate>

    {{-- Accessibility: screen readers announce status changes --}}
    <div aria-live="polite" aria-atomic="true">
        @if ($successMessage)
            <div role="status" class="p-4 rounded-lg bg-green-500/20 border border-green-500 text-green-400">
                {{ $successMessage }}
            </div>
        @endif
        @if ($errorMessage)
            <div role="alert" class="p-4 rounded-lg bg-red-500/20 border border-red-500 text-red-400">
                {{ $errorMessage }}
            </div>
        @endif
    </div>

    {{-- Honeypot: visually hidden, never filled by real users --}}
    <div aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;">
        <label for="website">Leave this empty</label>
        <input type="text" id="website" wire:model="honeypot" tabindex="-1" autocomplete="off">
    </div>

    <div>
        <label for="name" class="block text-sm font-medium mb-2" style="color: var(--text-muted)">
            Name <span aria-hidden="true" style="color:var(--green)">*</span>
        </label>
        <input
            wire:model="name"
            type="text"
            id="name"
            placeholder="Your name"
            required
            autocomplete="name"
            aria-required="true"
            aria-describedby="name-error"
            class="w-full px-4 py-2 rounded-lg border transition-colors"
            style="background: var(--surface); border-color: var(--border); color: var(--text)"
        />
        @error('name')
            <span id="name-error" role="alert" class="text-red-400 text-sm mt-1 block">{{ $message }}</span>
        @enderror
    </div>

    <div>
        <label for="email" class="block text-sm font-medium mb-2" style="color: var(--text-muted)">
            Email <span aria-hidden="true" style="color:var(--green)">*</span>
        </label>
        <input
            wire:model="email"
            type="email"
            id="email"
            placeholder="your@email.com"
            required
            autocomplete="email"
            aria-required="true"
            aria-describedby="email-error"
            class="w-full px-4 py-2 rounded-lg border transition-colors"
            style="background: var(--surface); border-color: var(--border); color: var(--text)"
        />
        @error('email')
            <span id="email-error" role="alert" class="text-red-400 text-sm mt-1 block">{{ $message }}</span>
        @enderror
    </div>

    <div>
        <label for="message" class="block text-sm font-medium mb-2" style="color: var(--text-muted)">
            Message <span aria-hidden="true" style="color:var(--green)">*</span>
        </label>
        <textarea
            wire:model="message"
            id="message"
            rows="5"
            placeholder="Your message..."
            required
            aria-required="true"
            aria-describedby="message-error"
            class="w-full px-4 py-2 rounded-lg border transition-colors resize-none"
            style="background: var(--surface); border-color: var(--border); color: var(--text)"
        ></textarea>
        @error('message')
            <span id="message-error" role="alert" class="text-red-400 text-sm mt-1 block">{{ $message }}</span>
        @enderror
    </div>

    <button
        type="submit"
        wire:loading.attr="disabled"
        class="px-6 py-2 rounded-lg font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        style="background: var(--green); color: white"
        aria-live="polite"
    >
        <span wire:loading.remove wire:target="submit">Send Message</span>
        <span wire:loading wire:target="submit" aria-label="Sending your message, please wait">Sending…</span>
    </button>

</form>
