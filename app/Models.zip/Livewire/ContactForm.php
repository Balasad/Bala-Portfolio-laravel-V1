<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\RateLimiter;

class ContactForm extends Component
{
    public string $name           = '';
    public string $email          = '';
    public string $message        = '';
    public string $honeypot       = '';  // hidden field — bots fill it, humans don't
    public bool   $isSubmitting   = false;
    public string $successMessage = '';
    public string $errorMessage   = '';

    protected function rules(): array
    {
        return [
            'name'     => 'required|min:2|max:100',
            'email'    => 'required|email|max:255',
            'message'  => 'required|min:10|max:5000',
            'honeypot' => 'size:0',
        ];
    }

    protected $messages = [
        'name.required'    => 'Please enter your name.',
        'email.required'   => 'Please enter your email address.',
        'email.email'      => 'Please enter a valid email address.',
        'message.required' => 'Please enter your message.',
        'message.min'      => 'Message must be at least 10 characters.',
    ];

    public function submit(): void
    {
        // Silently succeed for bots (honeypot filled)
        if ($this->honeypot !== '') {
            $this->reset(['name', 'email', 'message', 'honeypot']);
            $this->successMessage = 'Thank you! Your message has been sent successfully.';
            return;
        }

        $this->validate();

        // Rate-limit: max 3 attempts per IP per 10 minutes
        $key = 'contact-form:' . request()->ip();
        if (RateLimiter::tooManyAttempts($key, maxAttempts: 3)) {
            $seconds = RateLimiter::availableIn($key);
            $this->errorMessage = "Too many submissions. Please wait {$seconds} seconds and try again.";
            return;
        }
        RateLimiter::hit($key, decay: 600);

        $this->isSubmitting   = true;
        $this->errorMessage   = '';
        $this->successMessage = '';

        try {
            Mail::send([], [], function ($mail) {
                $mail->to(config('mail.contact_address', 'contact@bala.dev'))
                     ->replyTo($this->email, $this->name)
                     ->subject("Portfolio contact from {$this->name}")
                     ->html(
                         '<p><strong>Name:</strong> ' . e($this->name) . '</p>' .
                         '<p><strong>Email:</strong> ' . e($this->email) . '</p>' .
                         '<p><strong>Message:</strong></p><p>' . nl2br(e($this->message)) . '</p>'
                     );
            });

            $this->successMessage = 'Thank you! Your message has been sent successfully.';
            $this->reset(['name', 'email', 'message', 'honeypot']);
        } catch (\Exception $e) {
            $this->errorMessage = 'Something went wrong. Please try again or email me directly.';
            report($e);
        } finally {
            $this->isSubmitting = false;
        }
    }

    public function render(): \Illuminate\View\View
    {
        return view('livewire.contact-form');
    }
}
